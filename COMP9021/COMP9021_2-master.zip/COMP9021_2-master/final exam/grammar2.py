print('{:.1f}'.format(4.234324525254))
print('{:.0f}'.format(4.1))
# 进制转化，b o d x 分别表示二、八、十、十六进制
print('{:b}'.format(250))
print('{:o}'.format(250))
print('{:d}'.format(250))
print('{:x}'.format(250))
