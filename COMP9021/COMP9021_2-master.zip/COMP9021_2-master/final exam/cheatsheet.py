dir(list)
