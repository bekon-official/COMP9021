banknote_values = [1, 2, 5, 10, 20, 50, 100]
banknotes = dict.fromkeys(banknote_values, 0)
print(banknotes)
