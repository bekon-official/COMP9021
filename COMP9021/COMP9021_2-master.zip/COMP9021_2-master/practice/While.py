i = 5
while i > 0:
    print(i)
    i-=1#最重要，能够改变表达式 i-=1 is i=i-1

a=822.04*0.1
b=a-53.8
c =b/53.8
print(c)
print(b)

#eg2：
for i in range(1,10):
    while i = 10:
        print(i)
      i +=1
print("Done with loop")

def check_str(roman):
    for i in roman:
        if roman.count(i)>2:
            print("df")

check_str("III")