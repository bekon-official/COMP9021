# COMP9021 Practice 2 - Solutions


'''
Decodes all multiplications of the form

                       *  *  *x
                  x       *  *y
                    ----------
                    *  *  *  *product0
                    *  *  *    product 1
                    ---------- 
                    *  *  *  *  total

such that the sum of all digits in all 4 columns is constant.
'''
        
     
