# range(start, stop, step)
friends = ["Jim","Karen","Kevin"]

for index in range(len(friends)):
    print(friends[index])
    print(len(friends))

for i in range(0,10):
    print(i)