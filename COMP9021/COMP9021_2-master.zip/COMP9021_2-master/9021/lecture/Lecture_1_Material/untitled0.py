#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Sep 18 19:15:06 2019

@author: danzhao
"""

mark = 58
if mark > 50:
    print("pass")