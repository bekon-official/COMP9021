# COMP9021 20T3 - Rachid Hamadi
# Quiz 3 *** Due Friday Week 5 @ 10.00pm

# DO *NOT* WRITE YOUR NAME TO MAINTAIN ANONYMITY FOR PLAGIARISM DETECTION

# Prompts the user for an arity (a natural number) n and a word.
# Call symbol a word consisting of nothing but alphabetic characters
# and underscores.
# Checks that the word is valid, in that it satisfies the following
# inductive definition:
# - a symbol, with spaces allowed at both ends, is a valid word;
# - a word of the form s(w_1,...,w_n) with s denoting a symbol and
#   w_1, ..., w_n denoting valid words, with spaces allowed at both ends and
#   around parentheses and commas, is a valid word.


import sys


def is_valid(word, arity):
    return False
    # REPLACE THE RETURN STATEMENT ABOVE WITH YOUR CODE

try:
    arity = int(input('Input an arity : '))
    if arity < 0:
        raise ValueError
except ValueError:
    print('Incorrect arity, giving up...')
    sys.exit()
word = input('Input a word: ')
word=word.replace(' ','')
word=list(word)
def is_valid(st,arity,number):
    check=number
    i=0
    while i<len(st): 
        if st[0]=="(":
            print(str(1)+'tunnel') 
            return False
        elif st[i]==")":
            check+=1
            upper=i
            st.reverse()
            # if we cannot find the other pair return false
            try:
                lower=len(st)-st.index("(")-1
            except:
                print(str(4)+'tunnel') 
                return False
            print("the lower value is"+str(lower)+" the upper"+str(upper))
            st.reverse()
            i=lower-1
            print("into recursion")
            is_valid(st[lower+1:upper-1],arity,1)
            del st[lower:upper]
        elif st[i]==",":
            check+=1
            i+=1
        else:
            i+=1
    print(check)
    if check==arity:
        return True
    else:
        print(str(3)+'tunnel') 
        return False
if is_valid(word,arity,0):
    print('The word is valid.')
else:
    print('The word is invalid.')
